from __future__ import annotations
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageEnhance
from pathlib import Path
import numpy as np, cv2, zipfile, shutil, math, json, random, hashlib
from scipy.ndimage import gaussian_filter
random.seed(1307)
ROOT=Path('/mnt/data/cosmosimulator_planet_2d_v2')
AS=ROOT/'assets'
for sub in ('base','nature','terrain','water','effects','landing','characters/frames'):
 (AS/sub).mkdir(parents=True,exist_ok=True)
(ROOT/'demo').mkdir(parents=True,exist_ok=True)
(ROOT/'sources').mkdir(parents=True,exist_ok=True)
BASE=Path('/mnt/data/planet_colony_final_sprites')
BASE2=Path('/mnt/data/_new_unpacked')
if not BASE2.exists():
 with zipfile.ZipFile('/mnt/data/planet_colony_new_set_512.zip') as z:z.extractall(BASE2)
TEX=Path('/mnt/data/planet_surface_textures_512')

def save(img,p): p.parent.mkdir(exist_ok=True,parents=True);img.save(p)
def load(p):return Image.open(p).convert('RGBA')
def bboxcrop(im,pad=2):
 bb=im.getbbox()
 if not bb: return im
 x0,y0,x1,y1=bb
 return im.crop((max(0,x0-pad),max(0,y0-pad),min(im.width,x1+pad),min(im.height,y1+pad)))

# Existing approved assets, with exact filenames.
for p in sorted(BASE.glob('*.png')): shutil.copy2(p,AS/'base'/p.name)
for f in ['tree_old','tree_young','rock_large_cracked','rock_flat','bush_sparse','grass_dry']:
 shutil.copy2(BASE2/'nature'/f'{f}.png',AS/'nature'/f'{f}.png')
for p in TEX.glob('ground_*.png'):shutil.copy2(p,AS/'terrain'/p.name)
# Preserve existing tree/bush/grass/rock options as separate nature files.
for fname in ['tree','bush','grass_tuft','rock','ore_outcrop']:
 shutil.copy2(BASE/f'{fname}.png',AS/'nature'/f'{fname}.png')

# Nature add-ons assembled from existing source elements, rather than stylistic reinvention.
def place_on_rgba(base,source,rect):
 x,y,w,h=rect
 s=bboxcrop(source)
 s.thumbnail((w,h),Image.Resampling.LANCZOS)
 base.alpha_composite(s,(int(x+(w-s.width)//2),int(y+h-s.height)))

cluster=Image.new('RGBA',(512,512))
rocks=[load(AS/'nature'/'rock_flat.png'),load(AS/'nature'/'rock.png'),load(AS/'nature'/'rock_large_cracked.png')]
place_on_rgba(cluster,rocks[2],(130,180,250,200))
place_on_rgba(cluster,rocks[1],(70,277,210,155))
place_on_rgba(cluster,rocks[0],(257,305,145,94))
save(cluster,AS/'nature'/'rock_cluster.png')
cliff=Image.new('RGBA',(512,512))
place_on_rgba(cliff,rocks[2],(70,155,240,200))
place_on_rgba(cliff,rocks[1],(205,160,240,222))
place_on_rgba(cliff,rocks[0],(100,300,285,101))
save(cliff,AS/'nature'/'cliff_outcrop.png')
# A coastal rock cluster, same visual language.
shore=Image.new('RGBA',(512,512))
place_on_rgba(shore,rocks[0],(132,295,146,95))
place_on_rgba(shore,rocks[0],(255,324,124,75))
place_on_rgba(shore,rocks[1],(176,260,105,94))
save(shore,AS/'nature'/'shore_stones.png')

# Water: use previously supplied water texture; create shallow by muted recoloring.
water_src=np.asarray(Image.open(BASE2/'textures/water.png').convert('RGB').resize((512,512),Image.Resampling.LANCZOS),dtype=np.float32)
# Create seamless from source by four source quadrants with periodic crossfade on a wrapped map.
def periodize(rgb):
 # if source 512, use wrapped 512x512 quadrants sampled from a 768x768 extended array
 im=np.asarray(rgb,dtype=np.float32)
 h,w=im.shape[:2]
 # offset-blend two half-shifted copies, strongest offset near discontinuities
 out=im.copy()
 band=72
 for i in range(band):
  weight=(1+np.cos(np.pi*i/band))/4 # 0.5 to 0
  l=im[:,i,:].copy();r=im[:,w-1-i,:].copy()
  out[:,i,:]=l*(1-weight)+r*weight
  out[:,w-1-i,:]=r*(1-weight)+l*weight
 tmp=out.copy()
 for i in range(band):
  weight=(1+np.cos(np.pi*i/band))/4
  u=tmp[i,:,:].copy();d=tmp[h-1-i,:,:].copy()
  out[i,:,:]=u*(1-weight)+d*weight
  out[h-1-i,:,:]=d*(1-weight)+u*weight
 # force matching first and last rows/cols, edges alone are necessary not sufficient
 c=(out[:,0]+out[:,-1])/2;out[:,0]=c;out[:,-1]=c
 r=(out[0]+out[-1])/2;out[0]=r;out[-1]=r
 return out.clip(0,255).astype(np.uint8)

deep=periodize(water_src*.76+np.array([0,6,14]))
shallow=periodize(water_src*.79+np.array([28,42,29]))
save(Image.fromarray(deep,'RGB'),AS/'water'/'water_deep.png')
save(Image.fromarray(shallow,'RGB'),AS/'water'/'water_shallow.png')
# shore_wet is a material for shader mask, without drawn shoreline.
wet=np.asarray(Image.open(TEX/'ground_dry.png').convert('RGB'),dtype=np.float32)
wet=periodize(wet*.59+np.array([14,13,9]))
save(Image.fromarray(wet,'RGB'),AS/'water'/'shore_wet.png')
# fine low-alpha periodic detail for water, no large waves.
s=256;y,x=np.mgrid[0:s,0:s]; rng=np.random.default_rng(381)
noise=rng.normal(0,1,(s,s)).astype(np.float32)
noise=gaussian_filter(noise,3,mode='wrap')
noise/=max(noise.std(),1e-3)
field=np.sin(2*np.pi*(y*8/s+x*2/s+noise*.08))
a=np.clip((field-.82)*70,0,24).astype(np.uint8)
rgba=np.zeros((s,s,4),np.uint8);rgba[:,:,:3]=[198,230,215];rgba[:,:,3]=a
save(Image.fromarray(rgba,'RGBA'),AS/'water'/'water_ripple_overlay.png')

# Landing colony beacon/platform extracted from an illustrated concept sheet; real alpha cutout.
src=np.asarray(Image.open('/mnt/data/a_clean_high_resolution_game_asset_sheet_concep.png').convert('RGB'))
x0,y0,x1,y1=779,401,1138,639
crop=src[y0:y1,x0:x1].copy()
# Foreground from connected painted parts, reject dark concept-board background.
strength=crop.max(axis=2)
mask=(strength>60).astype(np.uint8)*255
mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((11,11),np.uint8))
n,lab,stats,_=cv2.connectedComponentsWithStats(mask,8)
k=max(range(1,n),key=lambda j:stats[j,cv2.CC_STAT_AREA]);mask=(lab==k).astype(np.uint8)*255
cnt,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(mask,cnt,-1,255,-1)
# Background region top left around other assets: exclude disconnected fragments.
mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
mask=cv2.GaussianBlur(mask,(3,3),.4)
# neutralize the edge dark board color only for semitransparent edge samples.
alpha=mask.astype(np.float32)/255
bg=np.array([35,34,33],np.float32)
corrected=np.clip((crop.astype(np.float32)-bg[None,None,:]*(1-alpha[:,:,None]))/np.maximum(alpha[:,:,None],.06),0,255).astype('uint8')
pod=Image.fromarray(np.dstack([corrected,mask]),'RGBA')
pod=bboxcrop(pod,5);pod.thumbnail((474,454),Image.Resampling.LANCZOS)
canvas=Image.new('RGBA',(512,512));canvas.alpha_composite(pod,((512-pod.width)//2,(512-pod.height)//2))
save(canvas,AS/'landing'/'colony_landing_core.png')

# UI/interaction effects, artist-defined soft rings, not terrain or magic effects.
def aa_draw(drawfn, size=128):
 big=Image.new('RGBA',(size*3,size*3));dr=ImageDraw.Draw(big)
 drawfn(dr,3)
 return big.resize((size,size),Image.Resampling.LANCZOS)
def draw_ring(d,k,fill,col,ds=(64,84),rad=27,arc=False):
 cx,cy=ds; b=(int((cx-rad)*k),int((cy-rad*.47)*k),int((cx+rad)*k),int((cy+rad*.47)*k))
 if fill:d.ellipse(b,fill=fill)
 if arc:
  for a in range(20,360,90):d.arc(b,a,a+46,fill=col,width=3*k)
 else:d.ellipse(b,outline=col,width=3*k)

save(aa_draw(lambda d,k:draw_ring(d,k,(26,168,156,16),(76,216,205,190),arc=True)),AS/'effects'/'move_target.png')
def blocked(d,k):
 draw_ring(d,k,(180,56,45,13),(239,126,103,192))
 d.line((53*k,74*k,75*k,94*k),fill=(226,95,85,205),width=3*k)
 d.line((75*k,74*k,53*k,94*k),fill=(226,95,85,205),width=3*k)
save(aa_draw(blocked),AS/'effects'/'move_blocked.png')
save(aa_draw(lambda d,k:draw_ring(d,k,(52,189,182,12),(135,237,230,150),rad=38,arc=True)),AS/'effects'/'selection_ring.png')
def sector(d,k):
 for yy in range(15,111,24):d.line((64*k,yy*k,64*k,min(yy+12,112)*k),fill=(151,221,227,194),width=4*k)
 d.arc((30*k,18*k,98*k,110*k),-65,65,fill=(151,221,227,155),width=2*k)
save(aa_draw(sector),AS/'effects'/'sector_boundary.png')
def footdust(d,k):
 for x,y,r,a in [(48,68,9,55),(71,71,8,46),(43,72,5,34),(78,76,4,30)]:
  d.ellipse(((x-r)*k,(y-r/2)*k,(x+r)*k,(y+r/2)*k),fill=(185,172,149,a))
save(aa_draw(footdust,size=128),AS/'effects'/'footstep_dust.png')

# Extract small designed turnarounds from source sheet and keep clean silhouettes.
sheet_a=np.asarray(Image.open('/mnt/data/a_high_resolution_concept_art_game_asset_atlas_c.png').convert('RGB'))
sheet_b=np.asarray(Image.open('/mnt/data/a_clean_high_resolution_game_asset_sheet_concep.png').convert('RGB'))
def cut_figure(src,rect,threshold=59):
 x0,y0,x1,y1=rect;rgb=src[y0:y1,x0:x1]
 val=np.max(rgb,axis=2)
 m=(val>threshold).astype(np.uint8)*255
 m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
 n,lb,st,_=cv2.connectedComponentsWithStats(m,8)
 # Allow both separated legs as long as near central body.
 good=[j for j in range(1,n) if st[j,cv2.CC_STAT_AREA]>34]
 if good:
  m=np.where(np.isin(lb,good),255,0).astype(np.uint8)
 contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 cv2.drawContours(m,contours,-1,255,-1)
 m=cv2.dilate(m,np.ones((2,2),np.uint8),iterations=1)
 m=cv2.GaussianBlur(m,(3,3),.5)
 a=m.astype(np.float32)/255
 bg=np.array([27,28,28],np.float32)
 rgb=np.clip((rgb.astype(np.float32)-bg[None,None,:]*(1-a[:,:,None]))/np.maximum(.12,a[:,:,None]),0,255).astype('uint8')
 return bboxcrop(Image.fromarray(np.dstack((rgb,m)),'RGBA'),2)

# Source poses: front and back from distinct hand-painted figures, side poses with true stepping legs.
pose={}
pose['down_idle']=bboxcrop(load(AS/'base'/'colonist.png'))
pose['down_step1']=cut_figure(sheet_a,(950,150,1020,248),57)
pose['down_step2']=cut_figure(sheet_a,(950,249,1020,336),57)
pose['up_idle']=cut_figure(sheet_a,(1017,39,1080,146),57)
pose['up_step1']=cut_figure(sheet_a,(1017,148,1080,245),57)
pose['up_step2']=cut_figure(sheet_a,(1017,247,1080,337),57)
pose['right_idle']=cut_figure(sheet_b,(285,185,349,283),58)
pose['right_step1']=cut_figure(sheet_b,(285,286,350,379),59)
pose['right_step2']=cut_figure(sheet_b,(353,286,420,379),59)
pose['right_step3']=cut_figure(sheet_b,(421,286,490,379),59)
pose['right_step4']=cut_figure(sheet_b,(491,286,560,379),59)
pose['right_step5']=cut_figure(sheet_b,(564,286,632,379),59)
pose['right_step6']=cut_figure(sheet_b,(634,286,702,379),59)
# 3/4 from the first atlas; character design consistent (helmet/teal, pack).
pose['downright_idle']=cut_figure(sheet_a,(1325,39,1392,147),57)
pose['downright_step1']=cut_figure(sheet_a,(1325,149,1392,248),57)
pose['downright_step2']=cut_figure(sheet_a,(1325,247,1392,337),57)
pose['upright_idle']=cut_figure(sheet_a,(1195,39,1261,146),57)
pose['upright_step1']=cut_figure(sheet_a,(1195,149,1261,248),57)
pose['upright_step2']=cut_figure(sheet_a,(1195,247,1261,337),57)
# Remove long translucent shadows around isolated feet; keep actual suit fully opaque.
# dir order chosen as clock-bearing directions with downward first.
dirs=['S','SW','W','NW','N','NE','E','SE']
map_sources={
 'S':['down_idle','down_step1','down_step2'],
 'SW':['downright_idle','downright_step1','downright_step2'],
 'W':['right_idle','right_step1','right_step2','right_step3','right_step4','right_step5','right_step6'],
 'NW':['upright_idle','upright_step1','upright_step2'],
 'N':['up_idle','up_step1','up_step2'],
 'NE':['upright_idle','upright_step1','upright_step2'],
 'E':['right_idle','right_step1','right_step2','right_step3','right_step4','right_step5','right_step6'],
 'SE':['downright_idle','downright_step1','downright_step2'],
}
def framed(s,width=128,height=128,bounce=0,mirror=False,angle=0):
 src=s.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if mirror else s.copy()
 # Emphasize silhouette over model-detail, consistent on-screen height.
 h=104;w=max(22,round(src.width/src.height*h));w=min(w,77)
 src=src.resize((w,h),Image.Resampling.LANCZOS)
 if angle: src=src.rotate(angle,Image.Resampling.BICUBIC,expand=True)
 im=Image.new('RGBA',(width,height))
 # center x, attach feet at y=115; small step bounce max 2px
 im.alpha_composite(src,((width-src.width)//2,115-src.height-bounce))
 return im
atlas=Image.new('RGBA',(7*128,8*128))
anim_info={'frameSize':[128,128],'columns':['idle','walk_0','walk_1','walk_2','walk_3','walk_4','walk_5'],
 'directions':dirs,'frameMs':135,'anchorPixel':[64,115], 'atlasSize':[896,1024], 'frameCount':56,
 'limitations':'Walk poses adapted from illustrated turnaround references; some diagonal orientations approximate, pending hand-drawn final animation.'}
for row,direction in enumerate(dirs):
 srcnames=map_sources[direction]
 mirrored=direction in ('SW','W','NW')
 for col in range(7):
  if col==0: p=pose[srcnames[0]];bounce=0
  else:
   if len(srcnames)==7: idx=[1,2,3,4,5,6][col-1]
   else: idx=[1,2,1,2,1,2][col-1]
   p=pose[srcnames[idx]];bounce=[0,1,2,1,0,1][col-1]
  frame=framed(p,bounce=bounce,mirror=mirrored)
  atlas.alpha_composite(frame,(col*128,row*128))
  save(frame,AS/'characters'/'frames'/f'{direction}_{"idle" if col==0 else f"walk_{col-1:02d}"}.png')
save(atlas,AS/'characters'/'colonist_8dir_atlas.png')
(ROOT/'assets'/'characters'/'colonist_8dir_atlas.json').write_text(json.dumps(anim_info,indent=2,ensure_ascii=False),encoding='utf-8')

# Documentation and layout metadata with draw sizes, anchor relative to image boundaries and footprint px.
assets={
 'base/habitat.png': {'draw':[360,360],'anchor':[.52,.85],'footprint':{'shape':'ellipse','rx':104,'ry':45}},
 'base/solar_panel.png':{'draw':[185,185],'anchor':[.50,.88],'footprint':{'shape':'circle','radius':22}},
 'base/cargo_container.png':{'draw':[177,177],'anchor':[.50,.77],'footprint':{'shape':'ellipse','rx':66,'ry':27}},
 'base/technical_node.png':{'draw':[190,190],'anchor':[.52,.85],'footprint':{'shape':'ellipse','rx':48,'ry':27}},
 'base/tree.png':{'draw':[224,224],'anchor':[.50,.78],'footprint':{'shape':'circle','radius':22}},
 'base/bush.png':{'draw':[96,96],'anchor':[.50,.82],'footprint':{'shape':'circle','radius':19}},
 'base/grass_tuft.png':{'draw':[57,57],'anchor':[.50,.87],'footprint':{'shape':'circle','radius':5}},
 'base/rock.png':{'draw':[145,145],'anchor':[.50,.80],'footprint':{'shape':'ellipse','rx':40,'ry':24}},
 'base/ore_outcrop.png':{'draw':[148,148],'anchor':[.50,.79],'footprint':{'shape':'ellipse','rx':44,'ry':24}},
 'base/mine_entrance.png':{'draw':[230,230],'anchor':[.50,.85],'footprint':{'shape':'ellipse','rx':75,'ry':43}},
 'base/colonist.png':{'draw':[104,104],'anchor':[.50,.86],'footprint':{'shape':'circle','radius':10}},
 'landing/colony_landing_core.png':{'draw':[352,352],'anchor':[.50,.86],'footprint':{'shape':'ellipse','rx':117,'ry':66}},
 'nature/tree_old.png':{'draw':[225,225],'anchor':[.50,.82],'footprint':{'shape':'circle','radius':24}},
 'nature/tree_young.png':{'draw':[160,160],'anchor':[.50,.82],'footprint':{'shape':'circle','radius':15}},
 'nature/bush_sparse.png':{'draw':[88,88],'anchor':[.50,.80],'footprint':{'shape':'circle','radius':16}},
 'nature/grass_dry.png':{'draw':[63,63],'anchor':[.50,.78],'footprint':{'shape':'circle','radius':5}},
 'nature/rock_flat.png':{'draw':[98,98],'anchor':[.50,.70],'footprint':{'shape':'ellipse','rx':27,'ry':12}},
 'nature/rock_large_cracked.png':{'draw':[168,168],'anchor':[.50,.78],'footprint':{'shape':'ellipse','rx':55,'ry':25}},
 'nature/rock_cluster.png':{'draw':[198,198],'anchor':[.50,.83],'footprint':{'shape':'ellipse','rx':74,'ry':36}},
 'nature/cliff_outcrop.png':{'draw':[248,248],'anchor':[.50,.82],'footprint':{'shape':'ellipse','rx':92,'ry':34}},
 'nature/shore_stones.png':{'draw':[140,140],'anchor':[.50,.80],'footprint':{'shape':'ellipse','rx':48,'ry':16}},
}
for fn in ('tree','bush','grass_tuft','rock','ore_outcrop'):
 assets['nature/'+fn+'.png']=assets['base/'+fn+'.png'].copy()
manifest={'name':'Cosmosimulator Planet 2D Art Pack','version':'0.2.0-preview','coordinateSystem':'world pixels; X increases right, Y increases down','render':{'camera':'orthographic top-down with slight object tilt','light':'upper-left','footSort':'draw assets by worldAnchorY','terrain':'tile in planet-global pixel coordinates; blend by procedural masks','footPoints':'normalized anchor is image drawRect x/y of ground contact'},'assets':assets,'character':anim_info,'notes':['Collision footprints are recommended approximations and must be tuned to actual navigation grids.','Landing object is a visual colony marker; gameplay existence is defined by game state, not PNG.','Water/shore geometry must come from procedural world masks.']}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')

# Representative 2D sector preview with global-coordinate water mask, no hard tile bank contours.
W,H=1440,900
tex={n:Image.open(AS/'terrain'/f'ground_{n}.png').convert('RGB') for n in ('grass','dry','sand','rock')}
# make a terrain with mask blend and pond curved shoreline
bg=Image.new('RGB',(W,H))
patch=tex['grass']
for yy in range(0,H,512):
 for xx in range(0,W,512): bg.paste(patch,(xx,yy))
arr=np.asarray(bg,dtype=np.float32).copy()
Y,X=np.mgrid[:H,:W]
noise=gaussian_filter(np.random.default_rng(45).random((H//4+1,W//4+1)).astype('float32'),8)
noise=cv2.resize(noise,(W,H),interpolation=cv2.INTER_CUBIC);noise=(noise-noise.min())/max(noise.ptp() if hasattr(noise,'ptp') else np.ptp(noise),1e-6)
# map patches: low contrast, not individual river sprites
for name,cx,cy,rx,ry,sharp in [('dry',700,460,620,500,1),('sand',190,650,440,560,1),('rock',1275,132,450,300,1)]:
 patch=np.asarray(tex[name],dtype=np.float32)
 pat=np.tile(patch,(math.ceil(H/512),math.ceil(W/512),1))[:H,:W]
 dd=((X-cx)/rx)**2+((Y-cy)/ry)**2
 m=np.clip((1.12-dd+(.5-noise)*.22)*1.8,0,1)
 if name=='dry':m*=.32
 elif name=='sand':m*=.6
 else:m*=.60
 arr=arr*(1-m[:,:,None])+pat*m[:,:,None]
# left/bottom pond with curved shoreline and sandy wet area
wave=24*np.sin(Y/75)+13*np.sin(Y/24+1.2)+7*np.sin(Y/13)
edge=205+0.16*(Y-500)+wave
signed=X-edge
wet_band=np.clip((46-signed)/38,0,1)*np.clip((signed+50)/30,0,1)
wetpix=np.tile(np.asarray(Image.open(AS/'water'/'shore_wet.png').convert('RGB'),dtype=np.float32),(2,3,1))[:H,:W]
arr=arr*(1-wet_band[:,:,None]*.48)+wetpix*wet_band[:,:,None]*.48
water=np.tile(np.asarray(Image.open(AS/'water'/'water_shallow.png').convert('RGB'),dtype=np.float32),(2,3,1))[:H,:W]
waterdeep=np.tile(np.asarray(Image.open(AS/'water'/'water_deep.png').convert('RGB'),dtype=np.float32),(2,3,1))[:H,:W]
wm=np.clip((edge-X)/26,0,1)
dm=np.clip((edge-X-70)/70,0,1)
color=water*(1-dm[:,:,None])+waterdeep*dm[:,:,None]
arr=arr*(1-wm[:,:,None])+color*wm[:,:,None]
# subtle bright foam right at wet coastline for demo only, water remains shader-defined
foam=np.exp(-(signed/7)**2)*((np.sin(Y/11+X/23)+1)/2)*.40
arr=arr*(1-foam[:,:,None])+np.array([193,214,196])*foam[:,:,None]
scene=Image.fromarray(arr.clip(0,255).astype('uint8'),'RGB').convert('RGBA')
save(scene.convert('RGB'),ROOT/'demo'/'terrain_background.png')
# Sort all by ground Y, retaining open navigation and visual grounding.
placements=[
 ('nature/tree_old.png',405,165),('nature/tree_young.png',1000,155),('base/tree.png',1314,150),
 ('nature/cliff_outcrop.png',1245,300),('nature/rock_large_cracked.png',1154,408),('nature/rock_cluster.png',535,270),
 ('base/habitat.png',675,495),('base/solar_panel.png',1020,450),('base/cargo_container.png',978,610),
 ('landing/colony_landing_core.png',808,280),('base/technical_node.png',1213,625),
 ('nature/rock_flat.png',370,668),('nature/shore_stones.png',284,757),
 ('base/bush.png',473,700),('nature/bush_sparse.png',1090,740),('nature/tree_young.png',1310,798),
 ('base/ore_outcrop.png',1018,800),('base/mine_entrance.png',1226,829),
 ('nature/grass_dry.png',659,770),('base/grass_tuft.png',835,690),
 ('base/colonist.png',777,655),('base/rock.png',438,826),('nature/tree_old.png',1366,620),
]
for rel,gx,gy in sorted(placements,key=lambda p:p[2]):
 info=assets[rel]; spr=load(AS/rel);dw,dh=info['draw'];spr=spr.resize((dw,dh),Image.Resampling.LANCZOS)
 ax,ay=info['anchor']; scene.alpha_composite(spr,(int(gx-dw*ax),int(gy-dh*ay)))
# subtle destination marker near character
marker=load(AS/'effects'/'move_target.png').resize((58,58),Image.Resampling.LANCZOS)
scene.alpha_composite(marker,(847-29,711-29))
save(scene.convert('RGB'),ROOT/'demo'/'sector_preview.png')

# Per-type contact sheet for easy visual inventory.
items=[p for p in (AS/'nature').glob('*.png')]+[AS/'landing'/'colony_landing_core.png']
thumb=Image.new('RGB',(4*360,math.ceil(len(items)/4)*300),'#454e4e')
d=ImageDraw.Draw(thumb)
for j,p in enumerate(items):
 x=(j%4)*360;y=(j//4)*300; im=load(p); im.thumbnail((326,255),Image.Resampling.LANCZOS)
 thumb.paste(im,(x+(360-im.width)//2,y+(260-im.height)//2),im)
 d.text((x+15,y+263),p.stem,fill='#e8edec')
save(thumb,ROOT/'demo'/'assets_preview.png')

# visual preview of eight directions idle and walk in an organized sheet.
charprev=Image.new('RGBA',(7*152+10,8*152+34),(46,57,58,255))
chard=ImageDraw.Draw(charprev)
for rid,direction in enumerate(dirs):
 chard.text((0,rid*152+72),direction,fill='#b9d7d2')
 for c in range(7):
  frame=atlas.crop((c*128,rid*128,(c+1)*128,(rid+1)*128))
  charprev.alpha_composite(frame,(28+c*152,rid*152+10))
save(charprev.convert('RGB'),ROOT/'demo'/'animation_preview.png')

# Data quality checks; do not claim perfect diagonals. RGB terrain alpha 255 and frame corners 0.
q={'terrain':{},'character':{'frames':56,'directions':8},'objects':{},'issues':[]}
for p in sorted((AS/'terrain').glob('*.png')):
 im=Image.open(p);a=np.asarray(im.convert('RGB')).astype(np.float32)
 q['terrain'][p.name]={'size':im.size,'mode':im.mode,'border_max_delta':int(max(np.max(abs(a[:,0]-a[:,-1])),np.max(abs(a[0]-a[-1]))))}
for p in list((AS/'base').glob('*.png'))+list((AS/'nature').glob('*.png'))+list((AS/'landing').glob('*.png')):
 im=Image.open(p).convert('RGBA');a=np.asarray(im)[:,:,3]
 q['objects'][p.name]={'size':im.size,'transparentPixels':int(np.sum(a==0)),'opaquePixels':int(np.sum(a==255))}
q['issues']=['Diagonal character views are adapted from available reference poses; they need hand-art review for a final production walk cycle.','Some reused nature sprites still have tiny ground-contact fragments; kept to preserve original design.','No editable layered PSD/ASE files were available; included PNG sources and generation script for derived resources.']
(ROOT/'qa_report.json').write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding='utf-8')

README='''# COSMOSIMULATOR — Планетарный 2D-режим: комплект графики (прототип v0.2.0)

Содержимое:
- `assets/base/`: 11 существующих утверждённых PNG-спрайтов, без художественного изменения.
- `assets/terrain/`: 6 ранее подготовленных бесшовных RGB PNG 512×512 (не регенерированы).
- `assets/nature/`: варианты растительности и препятствий из существующего дополнительного архива; несколько каменных композиций собраны из тех же исходников.
- `assets/landing/colony_landing_core.png`: отдельный визуальный объект высадки (RGBA).
- `assets/water/`: deep/shallow/shore_wet текстуры 512×512 и ненавязчивая 256×256 RGBA-рябь. Форма берега и воды не запечена в текстуру.
- `assets/effects/`: прозрачные PNG маркеров целевого, недоступного, выделенного и секторного состояния, а также пыли шага.
- `assets/characters/colonist_8dir_atlas.png`: 8 строк направлений S,SW,W,NW,N,NE,E,SE; 7 колонок (idle + 6 walk), ячейка 128×128; плюс 56 отдельных PNG-кадров в `frames/`.
- `manifest.json`: экранные размеры объектов, опоры и примерные следы столкновения. `assets/characters/colonist_8dir_atlas.json`: раскладка кадров.
- `demo/sector_preview.png`: демонстрационная сцена с грунтом, водой, деревьями, препятствиями и местом высадки.

## Интеграция с HTML Canvas

1. Текстуры грунта размещать в **единых мировых координатах**, а переходы суши/воды/биомов определять масками движка.
2. Для объектов использовать `draw`/`anchor` из `manifest.json`, `drawImage(x-width*anchorX, y-height*anchorY)`. Отрисовывать по возрастанию `y` опорной точки; коллизии считать по `footprint`, а не по квадрату 512×512.
3. Атлас анимации: `sx = column*128`, `sy = directionRow*128`, `sw=sh=128`; смена шага каждые ~135 мс; `idle` = column 0. Отрисовать в масштабе ~72-100 экранных пикселей по высоте.
4. Место высадки: отдельный объект `landing/colony_landing_core.png`; при первом появлении игрок стоит перед пандусом; пересечение с коллизией платформы не должно блокировать спавн.
5. Декоративные кольца/пометки — отдельный слой Canvas поверх грунта и под/над персонажем по смыслу. Не использовать изображение для определения механики воды, руды, владений.
6. Адаптировать размеры, столкновения и частоту шага под вашу реальную скорость передвижения и устройство камеры.

## Ограничения прототипа

Кадры боковых и диагональных направлений адаптированы из имеющихся иллюстрированных поз; это *не* полностью заново нарисованная согласованная восьмисторонняя покадровая анимация. Плавность и перспективу стоит проверить в игре до объявления релизной готовности. Силуэты в атласе — уменьшенные высококонтрастные игровые варианты. Дизайнерские PSD/ASE-слои не представлены: имеются исходные PNG/композит и генератор производных материалов. Полноценную интеграцию в репозиторий игры этот пакет сам не выполняет.

См. `qa_report.json` для фактических форматов, проверки краёв и отмеченных ограничений.
'''
(ROOT/'README.md').write_text(README,encoding='utf-8')
shutil.copy2('/mnt/data/build_cosmosimulator.py',ROOT/'sources'/'build_cosmosimulator.py')
# archive final
archive=Path('/mnt/data/cosmosimulator_planet_2d_artpack_v2.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(ROOT.rglob('*')):
  if f.is_file():z.write(f,arcname=str(f.relative_to(ROOT)))
print('ROOT',ROOT,'ARCHIVE',archive,'ZIP_BYTES',archive.stat().st_size)
print('IMGFILES',len(list(ROOT.rglob('*.png'))))
print('TERRAINQA',json.dumps(q['terrain'],ensure_ascii=False)[:500])
