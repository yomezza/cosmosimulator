from pathlib import Path
import json, zipfile, shutil
root=Path('/mnt/data/cosmosimulator_planet_2d_v2')
assets=json.loads((root/'manifest.json').read_text())['assets']
# screen positions synced with rendered screenshot
positions=[
 ('nature/tree_old.png',405,165),('nature/tree_young.png',1000,155),('base/tree.png',1314,150),
 ('nature/cliff_outcrop.png',1245,300),('nature/rock_large_cracked.png',1154,408),('nature/rock_cluster.png',535,270),
 ('base/habitat.png',675,495),('base/solar_panel.png',1020,450),('base/cargo_container.png',978,610),
 ('landing/colony_landing_core.png',808,280),('base/technical_node.png',1213,625),
 ('nature/rock_flat.png',370,668),('nature/shore_stones.png',284,757),
 ('base/bush.png',473,700),('nature/bush_sparse.png',1090,740),('nature/tree_young.png',1310,798),
 ('base/ore_outcrop.png',1018,800),('base/mine_entrance.png',1226,829),
 ('nature/grass_dry.png',659,770),('base/grass_tuft.png',835,690),
 ('base/rock.png',438,826),('nature/tree_old.png',1366,620)
]
items=[{'key':r,'x':x,'y':y,'size':assets[r]['draw'],'anchor':assets[r]['anchor'],'collider':assets[r]['footprint']} for r,x,y in positions]
page='''<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cosmosimulator — Planetary graphics demo</title>
<style>
html,body{height:100%;margin:0;background:#172023;color:#dae8e6;font:13px system-ui, sans-serif;}
main{height:100%;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:9px;padding:12px;box-sizing:border-box;}
canvas{display:block;width:min(96vw,calc(93vh * 1.6));height:auto;max-height:90vh;object-fit:contain;border:1px solid #364449;box-shadow:0 14px 50px #0008;cursor:crosshair;}
.help{opacity:.75;text-align:center} .help b{color:#9cdddd}
</style></head><body><main>
<canvas id="game" width="1440" height="900" aria-label="Пробная планетарная сцена"></canvas>
<div class="help"><b>Cosmosimulator · Graphics Demo</b> — нажмите на землю для движения · недоступны вода и области построек · наведите на объект для подсветки</div>
</main><script>
'use strict';
const ITEMS = __ITEMS__;
const DIRS = ['S','SW','W','NW','N','NE','E','SE'];
const c=document.getElementById('game'),ctx=c.getContext('2d');
const loaded={};const needed=['terrain_background.png','../assets/characters/colonist_8dir_atlas.png',
'../assets/effects/move_target.png','../assets/effects/move_blocked.png','../assets/effects/selection_ring.png','../assets/effects/sector_boundary.png',
...ITEMS.map(i=>'../assets/'+i.key)];
for(const path of new Set(needed)){const img=new Image();img.src=path; loaded[path]=img;}
const actor={x:777,y:655,direction:0,moving:false,target:null,lastTime:0};
let mouse={x:-100,y:-100},effect=null,nearest=null,last=performance.now();
const lakeEdge=y=>205+.16*(y-500)+24*Math.sin(y/75)+13*Math.sin(y/24+1.2)+7*Math.sin(y/13);
function isBlocked(x,y){
 if(x<lakeEdge(y)+15||x<15||x>1420||y<20||y>890)return true;
 for(const o of ITEMS){const f=o.collider;const dx=x-o.x,dy=y-o.y;
  if(f.shape==='circle'&&(dx*dx+dy*dy)<(f.radius+9)**2)return true;
  if(f.shape==='ellipse'&&(dx/(f.rx+9))**2+(dy/(f.ry+7))**2<1)return true;
 }return false;
}
function point(ev){const r=c.getBoundingClientRect();return{x:(ev.clientX-r.left)*c.width/r.width,y:(ev.clientY-r.top)*c.height/r.height};}
c.addEventListener('pointermove',ev=>{mouse=point(ev);nearest=null;let smallest=1e9;
 for(const o of ITEMS){const dx=mouse.x-o.x,dy=mouse.y-o.y;
 const dist=Math.hypot(dx,dy);let range=50+o.size[0]*.16;if(dist<range&&dist<smallest){nearest=o;smallest=dist;}}
});
c.addEventListener('pointerleave',()=>mouse={x:-100,y:-100});
c.addEventListener('pointerdown',ev=>{const p=point(ev); if(isBlocked(p.x,p.y)){effect={x:p.x,y:p.y,blocked:true,time:performance.now()};return;}
 actor.target={x:p.x,y:p.y};effect={x:p.x,y:p.y,blocked:false,time:performance.now()};});
function render(time){const dt=Math.min(.05,(time-last)/1000);last=time;
 if(actor.target){let dx=actor.target.x-actor.x,dy=actor.target.y-actor.y;const distance=Math.hypot(dx,dy);
  if(distance<3){actor.target=null;actor.moving=false;}else{
   const angle=((Math.atan2(dy,dx)*180/Math.PI)+360)%360;
   actor.direction=Math.round(((angle-90+360)%360)/45)%8;
   const step=Math.min(distance,130*dt);const nx=actor.x+dx/distance*step,ny=actor.y+dy/distance*step;
   if(isBlocked(nx,ny)){actor.target=null;actor.moving=false;effect={x:nx,y:ny,blocked:true,time:time};}
   else {actor.x=nx;actor.y=ny;actor.moving=true;}
  }
 }
 ctx.clearRect(0,0,1440,900);
 const bg=loaded['terrain_background.png'];if(bg?.complete&&bg.naturalWidth)ctx.drawImage(bg,0,0,1440,900);
 const sprites=ITEMS.concat([{key:'__actor',x:actor.x,y:actor.y}]).sort((a,b)=>a.y-b.y);
 for(const o of sprites){
  if(o.key==='__actor'){
   const atlas=loaded['../assets/characters/colonist_8dir_atlas.png'];
   if(atlas?.complete&&atlas.naturalWidth){const frame=actor.moving?1+(Math.floor(time/135)%6):0;
    ctx.drawImage(atlas,frame*128,actor.direction*128,128,128,actor.x-48,actor.y-86,96,96);}
  }else{
   const img=loaded['../assets/'+o.key];if(img?.complete&&img.naturalWidth){ctx.drawImage(img,o.x-o.size[0]*o.anchor[0],o.y-o.size[1]*o.anchor[1],o.size[0],o.size[1]);}
  }
 }
 if(nearest){const img=loaded['../assets/effects/selection_ring.png'];if(img?.complete&&img.naturalWidth){
  ctx.drawImage(img,nearest.x-56,nearest.y-60,112,112);}}
 if(effect){const alive=time-effect.time; if(alive>1550)effect=null;else{
  const key=effect.blocked?'move_blocked.png':'move_target.png';const img=loaded['../assets/effects/'+key];
  if(img?.complete&&img.naturalWidth){ctx.save();ctx.globalAlpha=Math.max(.1,1-alive/1550);
   ctx.drawImage(img,effect.x-48,effect.y-63,96,96);ctx.restore();}}
 }
 const sb=loaded['../assets/effects/sector_boundary.png'];if(sb?.complete&&sb.naturalWidth)ctx.drawImage(sb,1345,388,96,128);
 requestAnimationFrame(render);
}
requestAnimationFrame(render);
</script></body></html>'''
page=page.replace('__ITEMS__',json.dumps(items,ensure_ascii=False,separators=(',',':')))
(root/'demo'/'index.html').write_text(page,encoding='utf-8')
md=root/'README.md'
s=md.read_text(encoding='utf-8')
s+='\n## Интерактивная демонстрация Canvas\n\nОткройте `demo/index.html` в современном браузере (или запустите `python -m http.server` из каталога пакета). Пример рисует текстуры, выполняет сортировку объектов по Y опорной точки и воспроизводит атлас при движении мышью. Прямолинейное движение, простые приблизительные коллизии и подсветка — демонстрация, **не** финальный поиск пути по навигационной сетке.\n'
md.write_text(s,encoding='utf-8')
shutil.copy2('/mnt/data/create_canvas_demo.py',root/'sources'/'create_canvas_demo.py')
archive=Path('/mnt/data/cosmosimulator_planet_2d_artpack_v2.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file():z.write(f,arcname=str(f.relative_to(root)))
print('ZIP',archive, archive.stat().st_size,'files',len(zipfile.ZipFile(archive).namelist()))
